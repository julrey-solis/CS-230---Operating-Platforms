package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */


/*
 * This is the new Team class code
 * Per Project One Rubric, I recoded to inherit from the new Entity class.
 */

public class Team extends Entity {
	
	// Created a private list of Player objects
	private List<Player> players = new ArrayList<>();
	
	//this is for the Team ID which starts from one whenever you add a team object to the teams list.
	private long nextPlayerId = 1;
	
	//Inherits the private attributes of the entity class (id and name)
	// I also added Game game in order to reference the current Game object where the Team object belongs to.
	public Team(long id, String name, Game game) {
        super(id, name);   
        this.game = game;
    }
	
	// I added this and line 37 so I can call on the parent Game object of where the team object belongs to
	private Game game;
	
		
	//addPlayer method is to add a new Player object to the players list.
	public Player addPlayer(String playerName) {
		
		// a local player instance
		Player player = null;

        // Check if a player with the same name already exists
        for (Player p : players) {
            if (p.getName().equalsIgnoreCase(playerName)) {
            	System.out.println("Player already exists.");
                return p;   // Return existing player
            }
        }

        // Create a new player
        if (player == null) {
        	player = new Player(nextPlayerId++, playerName);
        }
        players.add(player);
        System.out.println();
		System.out.println("player " + playerName + "\n"
				+ "ID: "+ player.getId() + "\n"
						+ "had been added to team " + getName()
						+ " in game " + game.getName() + ".");
		System.out.println();

        return player;
    }
	
	public Player getPlayer(String name) {

		Player player = null;
		for (Player existingPlayer : players) {
			if (existingPlayer.getName().equalsIgnoreCase(name)) {
				return existingPlayer;
			}
		}

		return player;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + getId() + ", name=" + getName() + "]";
	}
	
	public List<Player> getPlayers() {
	    return players;
	}

}
