

package com.gamingroom;

 /**
  * JSOLIS 5/22/2026
  * Created the new Entity superclass as per the Gaming Room UML Diagram
  * 
  * This class will be inherited by the Game, Team and Player class objects.
 */

public class Entity {
	
	private long id;
	private String name;
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Entity() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Entity(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	public String toString() {
		
		return "Entity [id=" + id + ", name=" + name + "]";
	}

}
