package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * @author coce@snhu.edu
 */
public class SingletonTester {

	public void testSingleton() {
		
		System.out.println("\nAbout to test the singleton...");
		
		// FIXME: obtain local reference to the singleton instance
		/*
		 * (COMPLETED - JULREY SOLIS) 
		 * I changed null with the method GameService.getGameService();
		 * This will check if the GameService had already been instantiated.
		 */
		GameService service = GameService.getGameService(); // replace null with ???
		
		// a simple for loop to print the games
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
		}

	}
	
}
