package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// FIXME: Add missing pieces to turn this class a singleton 
	/*
	 * (COMPLETED - Julrey Solis) 
	 * I added the private GameService() constructor to make sure that only one instance of the GameService class exists in memory at any time.
	 * Then, I also added a getGameService() method to check whether the newGameService has already been instantiated.
	 * System will print "New game created" if the object has not been instantiated, and will print "Game already opened" if it had already been.
	 */
	private GameService(){}
	
	private static GameService instance;
	
	public static GameService getGameService() {
		if (instance == null) {
			instance = new GameService();
            System.out.println("New GameService created.");
        } else {
            System.out.println("GameService already opened.");
        }
        return instance;
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply return the existing instance
		/*
		 * (COMPLETED - Julrey Solis)
		 * I added a for loop that will iterate through the list of (Game)games
		 * the temporary existingGame object will be matched through the list to check if the name had already been added by using the equalsIgnoreCase method
		 * If it matches, then the iterator will simply print "Game already exists." and return the existingGame object.
		 */
		for (Game existingGame : games) {
			if (existingGame.getName().equalsIgnoreCase(name)) {
				System.out.println("Game already exists.");
				return existingGame;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
			System.out.println();
			System.out.println(name + " game\n"
					+ "ID: "+ game.getId() + "\n"
							+ "had been added.");
			System.out.println();
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable
		/*
		 * (COMPLETED - Julrey Solis)
		 * I added a for loop that will iterate through the list of (Game)games
		 * the existingGame object's Id will be matched with the games' instances.
		 * If it matches, then the iterator will return that instance.
		 */
		for (Game existingGame : games) {
			if (existingGame.getId() == id) {
				System.out.println("Game ID:"+ id +"found");  
				return existingGame;
			}
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable
		/*
		 * (COMPLETED - Julrey Solis)
		 * I added a for loop that will iterate through the list of (Game)games
		 * the existingGame object's name will be matched with the games' instances.
		 * If it matches, then the iterator will return that instance.
		 */
		for (Game existingGame : games) {
			if (existingGame.getName().equalsIgnoreCase(name)) {
				return existingGame;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	/*
	 * JSOLIS - Created this method to print the list of all games, teams and players object to prove that the application is working correctly.
	 */
	public void printEverything() {
		System.out.println();
		System.out.println("**************************************");
	    System.out.println("*           FULL GAME LIST           *");
	    System.out.println("**************************************");
	    System.out.println();
	    
	    for (Game g : games) {
	    	System.out.println("    " + g.getName() + "\t\t\t\t(ID " + g.getId() + ")");

	        for (Team t : g.getTeams()) {
	            System.out.println("       " + t.getName() + " team \t\t\t(ID " + t.getId() + ")");

	            for (Player p : t.getPlayers()) {
	                System.out.println("          " + p.getName() + "\t\t\t(ID " + p.getId() + ")");
	            }
	        }
	    }
	}

}
