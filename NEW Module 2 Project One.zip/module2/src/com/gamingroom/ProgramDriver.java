package com.gamingroom;

// JSOLIS - I added the Scanner package to get inputs from user
import java.util.Scanner; 

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	
	
	public static void main(String[] args) {
		
		/*
		 * (COMPLETED - JULREY SOLIS) 
		 * I changed null with the method GameService.getGameService();
		 * This will check if the GameService had already been instantiated.
		 */
				
		GameService service = GameService.getGameService(); // replace null with ???
		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		
			   			
		Scanner scnr = new Scanner(System.in);			//JSOLIS : Added scanner class for user input.
        char i = '0';									// JSOLIS: added i counter variable for looping.
        
        /*				
         * JSOLIS	
         *	Used while-loop to keep displaying the menu until 
         *	user inputs 'q' and then it will print "Goodbye!"
         *
         */
        while (i != 'q') {								
        	displayMenu();								
        	i = scnr.next().charAt(0);
        	
        	if (i == '1') {
        		service.addGame(gameName(scnr = new Scanner(System.in)));
        	}
        	
        	else if (i == '2') {
        		Game temp_game = service.getGame(gameName(scnr = new Scanner(System.in)));
        		temp_game.addTeam(teamName(scnr = new Scanner(System.in)));
        		
        		
        	}
        	
        	else if (i == '3') {
        		Game temp_game = service.getGame(gameName(scnr = new Scanner(System.in)));
        		Team temp_team = temp_game.getTeam(teamName(scnr = new Scanner(System.in)));
        		temp_team.addPlayer(playerName(scnr = new Scanner(System.in)));
        	
        	}
        	
        	else if (i == '4') {
        	    System.out.println("\nFind game by ID or name:");
        	    System.out.print("Enter game ID (number) or game name: ");

        	    String input = scnr.next();   // read as string

        	    Game temp_game;

        	    // Check if input is numeric (ID)
        	    if (input.matches("\\d+")) {
        	        long id = Long.parseLong(input); // if input is true, then it will use Long (id) for the overload method.
        	        temp_game = service.getGame(id);
        	    } 
        	    else {
        	        temp_game = service.getGame(input); // if false, then it will use String (input) for the overload method.
        	    }

        	    if (temp_game == null) {
        	        System.out.println("Game not found.");
        	    } 
        	    else {
        	        System.out.println("    " + temp_game.getName() + "\t\t\t\t(ID " + temp_game.getId() + ")");
        	        for (Team t : temp_game.getTeams()) {
        	            System.out.println("       " + t.getName() + " team \t\t\t(ID " + t.getId() + ")");
        	            for (Player p : t.getPlayers()) {
        	                System.out.println("          " + p.getName() + "\t\t\t(ID " + p.getId() + ")");
        	            }
        	        }
        	    }
        	}

        	
        	else if (i == '5') {
        		service.printEverything();
        	
        	}
        	        	
        	else if (i == 'q') {
        		System.out.println("Goodbye!");	
        		
        	}
        	
        	else {
        		System.out.println("Invalid input, please try again.");
        	}
        }
        
     // use another class to prove there is only one instance
     		SingletonTester tester = new SingletonTester();
     		tester.testSingleton();
     		
     		System.out.println("\n\n");
     		     		
	}
	
	
    // -----------------------------
    // Helper Methods
    // -----------------------------
	
	// A simple method to display the menu option of the application
	public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("Menu Option.");
        System.out.println("\t [1] Add a new game.");
        System.out.println("\t [2] Add a new team.");
        System.out.println("\t [3] Add a new player.");
        System.out.println("\t [4] Find game (By ID / name).");
        System.out.println("\t [5] Print all list.");
        System.out.println("\t [q] Quit application");
        System.out.println();
        System.out.print("\t Enter option here:");
    }
	
	
	// A simple method to take user input to get the game name.
	public static String gameName(Scanner scanner) {
		System.out.println();
        System.out.print("\t What's the Game's name?");
        String gameName = scanner.nextLine();
        return gameName;
        }
	
	// A simple method to take user input to get the team name.
	public static String teamName(Scanner scanner) {
        System.out.println();
        System.out.print("What's the Team's name?");
        String teamName = scanner.nextLine();  
        return teamName;
        }
	
	// A simple method to take user input to get the player name.
	public static String playerName(Scanner scanner) {
		System.out.println();
        System.out.println("What's the Player's name?");
        String name = scanner.nextLine();
        return name;
        }
	        
}


 
