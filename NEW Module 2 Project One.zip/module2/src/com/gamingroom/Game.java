package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */


/*
 * This is the new Game class code
 * Per Project One Rubric, I recoded to inherit from the new Entity class.
 */
public class Game extends Entity{
	
	// Created a private list of Team objects
	private List<Team> teams = new ArrayList<>();
	
	//this is for the Team ID which starts from one whenever you add a team object to the teams list.
	private long nextTeamId = 1;
	
	//Inherits the private attributes of the entity class (id and name)
	public Game(long id, String name) {
        super(id, name);   
    }

	//addTeam method is to add a new Team object to the teams list.
	public Team addTeam(String teamName) {
				
		// Check if a team with the same name already exists
        for (Team t : teams) {
            if (t.getName().equalsIgnoreCase(teamName)) {
            	System.out.println("Team already exists.");
                return t;   // Return existing team
            }
        }

        // Create a new team
        Team team = new Team(nextTeamId++, teamName, this);
        teams.add(team);
        System.out.println();
		System.out.println(teamName + " team\n"
				+ "ID: "+ team.getId() + "\n"
						+ "had been added to game " + getName() + ".");
		System.out.println();

        return team;
    }
	
	public Team getTeam(String name) {

		Team team = null;
		for (Team existingTeam : teams) {
			if (existingTeam.getName().equalsIgnoreCase(name)) {
				return existingTeam;
			}
		}

		return team;
	}


	@Override
	public String toString() {
		
		return "Game [id=" + getId() + ", name=" + getName() + "]";
	}
	
	public List<Team> getTeams() {
	    return teams;
	}


}
